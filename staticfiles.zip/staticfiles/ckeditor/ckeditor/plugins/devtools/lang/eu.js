﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","eu",{title:"Elementuaren Informazioa",dialogName:"Elkarrizketa leihoaren izena",tabName:"Fitxaren izena",elementId:"Elementuaren ID-a",elementType:"Elementu mota"});